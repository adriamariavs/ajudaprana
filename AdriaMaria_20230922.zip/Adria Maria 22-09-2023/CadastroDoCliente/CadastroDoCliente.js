var http = require('http');
var dt= require('./moduleCadastroDoCliente');


http.createServer( function (req,res) {
res.writeHead(200, {'Content-Type': 'text/html'});
res.write("Bem Vindo ao Cadastro do Cliente"  +  dt.myDateTime());
res.end();
}).listen(5009);
