var http = require('http');
var dt= require('./myfirstmodule');


http.createServer( function (req,res) {
res.writeHead(200, {'Content-Type': 'text/html'});
res.write("Bem Vindo a página de consultas"+dt.myDateTime());
res.end();
}).listen(5010);
